#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <syscall.h>
#include <sys/mman.h>
#include <sys/random.h>
#include <unistd.h>

#define N_MEM 16
#define N_REG 4
#define MEMSPACE_SIZE 0x1000
#define CODE_BASE 0xc0de000000
#define REG_DST(insn) ((size_t)((insn) & 0b0011))
#define REG_SRC(insn) ((size_t)(((insn) & 0b1100)) >> 2)
#define SEL(insn) ((size_t)((insn) & 0b1111))

#define RND_A 0x41c64e6d
#define RND_B 0x6073

typedef void (*rand_func_t)();

struct {
  rand_func_t gen;
  uint8_t *mem[N_MEM];
  uint32_t reg[N_REG];
  size_t sel;
  size_t pc;
  size_t jmp;
  uint32_t seed;
  uint32_t auth;
  int auth_ok;
  int exception;
} vm;

void vm_rand_lcg() {
  vm.seed = vm.seed * RND_A + RND_B;
}

void vm_rand_xorshift() {
  vm.seed ^= vm.seed << 13;
  vm.seed ^= vm.seed >> 17;
  vm.seed ^= vm.seed << 5;
}

void vm_insn_special(const uint8_t *code, uint8_t insn) {
  if ((insn & 0x08) == 0) {
    switch (insn & 0x07) {
      case 0: break;
      case 1:
        vm.reg[0] = *(uint32_t*)(code + vm.pc);
        vm.pc += sizeof(uint32_t);
        break;

      case 2:
        if (vm.sel != 0xffffffffffffffff && vm.mem[vm.sel])
          vm.exception = 1;
        else {
          vm.mem[vm.sel] = (uint8_t*)mmap(NULL, MEMSPACE_SIZE, PROT_READ|PROT_WRITE,
                                          MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
          if (vm.mem[vm.sel] == MAP_FAILED)
            vm.exception = 1;
        }
        break;

      case 3:
        if (vm.mem[vm.sel] &&
            !munmap(vm.mem[vm.sel], MEMSPACE_SIZE))
          vm.mem[vm.sel] = NULL;
        else
          vm.exception = 1;
        break;

      case 4:
        vm.gen();
        vm.gen = vm.seed & 1 ? vm_rand_lcg : vm_rand_xorshift;
        vm.reg[0] = vm.seed >> 1;
        break;

      case 5: vm.pc = MEMSPACE_SIZE; break;

      case 6:
        if (vm.reg[0] == vm.auth &&
            getrandom(&vm.auth, sizeof(vm.auth), 0) == sizeof(vm.auth))
          vm.auth_ok = 1;
        else
          vm.exception = 1;
        break;

      case 7:
        if (vm.auth_ok) {
          vm.auth_ok = 0;
          syscall(vm.reg[0], vm.reg[1], vm.reg[2], vm.reg[3], -1, -1, -1);
        } else
          vm.exception = 1;
        break;
    }

  } else {
    if (vm.reg[REG_DST(insn)] >= MEMSPACE_SIZE)
      vm.exception = 1;
    else
      vm.jmp = vm.reg[REG_DST(insn)];
  }
}

void vm_insn_mov(uint8_t insn) {
  vm.reg[REG_DST(insn)] = vm.reg[REG_SRC(insn)];
}

void vm_insn_sel(uint8_t insn) {
  vm.sel = SEL(insn);
}

void vm_insn_ld(uint8_t insn) {
  if (!vm.mem[vm.sel]) {
    vm.exception = 1;
  } else {
    size_t addr = vm.reg[REG_SRC(insn)] % MEMSPACE_SIZE;
    vm.reg[REG_DST(insn)] = (uint32_t)vm.mem[vm.sel][addr];
  }
}

void vm_insn_st(uint8_t insn) {
  if (!vm.mem[vm.sel]) {
    vm.exception = 1;
  } else {
    size_t addr = vm.reg[REG_DST(insn)] % MEMSPACE_SIZE;
    vm.mem[vm.sel][addr] = (uint8_t)vm.reg[REG_SRC(insn)];
  }
}

void vm_insn_jmp(uint8_t insn) {
  if (vm.jmp == 0xffffffffffffffff)
    vm.exception = 1;
  else
    vm.pc = vm.jmp;
}

void vm_insn_jeq(uint8_t insn) {
  if (vm.jmp == 0xffffffffffffffff)
    vm.exception = 1;
  else if (vm.reg[REG_DST(insn)] == vm.reg[REG_SRC(insn)])
    vm.pc = vm.jmp;
}

void vm_insn_jge(uint8_t insn) {
  if (vm.jmp == 0xffffffffffffffff)
    vm.exception = 1;
  else if (vm.reg[REG_DST(insn)] >= vm.reg[REG_SRC(insn)])
    vm.pc = vm.jmp;
}

void vm_insn_add(uint8_t insn) {
  vm.reg[REG_DST(insn)] += vm.reg[REG_SRC(insn)];
}

void vm_insn_sub(uint8_t insn) {
  vm.reg[REG_DST(insn)] -= vm.reg[REG_SRC(insn)];
}

void vm_insn_mul(uint8_t insn) {
  vm.reg[REG_DST(insn)] *= vm.reg[REG_SRC(insn)];
}

void vm_insn_div(uint8_t insn) {
  if (vm.reg[REG_SRC(insn)] == 0)
    vm.exception = 1;
  else
    vm.reg[REG_DST(insn)] /= vm.reg[REG_SRC(insn)];
}

void vm_insn_mod(uint8_t insn) {
  if (vm.reg[REG_SRC(insn)] == 0)
    vm.exception = 1;
  else
    vm.reg[REG_DST(insn)] %= vm.reg[REG_SRC(insn)];
}

void vm_insn_and(uint8_t insn) {
  vm.reg[REG_DST(insn)] &= vm.reg[REG_SRC(insn)];
}

void vm_insn_or(uint8_t insn) {
  vm.reg[REG_DST(insn)] |= vm.reg[REG_SRC(insn)];
}

void vm_insn_xor(uint8_t insn) {
  vm.reg[REG_DST(insn)] ^= vm.reg[REG_SRC(insn)];
}

void vm_init() {
  vm.gen = vm_rand_lcg;
  for (size_t i = 0; i < N_MEM; i++)
    vm.mem[i] = NULL;
  for (size_t i = 0; i < N_REG; i++)
    vm.reg[i] = 0;
  vm.pc  = 0;
  vm.sel = 0xffffffffffffffff;
  vm.jmp = 0xffffffffffffffff;
  if (getrandom(&vm.seed, sizeof(vm.seed), 0) != sizeof(vm.seed))
    _exit(1);
  vm.auth = vm.seed;
  vm.auth_ok = 0;
  vm.exception = 0;
}

void vm_run(const uint8_t *code) {
  uint32_t ins_cnt = 0;
  vm_init();

  while (vm.pc < MEMSPACE_SIZE) {
    uint8_t insn = code[vm.pc++];
    switch (insn & 0xF0) {
      case 0x00: vm_insn_special(code, insn); break;
      case 0x10: vm_insn_mov(insn); break;
      case 0x20: vm_insn_sel(insn); break;
      case 0x30: vm_insn_ld(insn); break;
      case 0x40: vm_insn_st(insn); break;
      case 0x50: vm_insn_jmp(insn); break;
      case 0x60: vm_insn_jeq(insn); break;
      case 0x70: vm_insn_jge(insn); break;
      case 0x80: vm_insn_add(insn); break;
      case 0x90: vm_insn_sub(insn); break;
      case 0xa0: vm_insn_mul(insn); break;
      case 0xb0: vm_insn_div(insn); break;
      case 0xc0: vm_insn_mod(insn); break;
      case 0xd0: vm_insn_and(insn); break;
      case 0xe0: vm_insn_or(insn); break;
      case 0xf0: vm_insn_xor(insn); break;
    }

    if (vm.exception) {
      puts("[-] Exception");
      break;
    }

    if (ins_cnt++ >= 0x1000) {
      puts("[-] Insufficient resource");
      break;
    }
  }

  puts("[+] Execution done");
  printf(" R0 = 0x%08x\n"
         " R1 = 0x%08x\n"
         " R2 = 0x%08x\n"
         " R3 = 0x%08x\n",
         vm.reg[0], vm.reg[1], vm.reg[2], vm.reg[3]);
}

int main() {
  setbuf(stdout, NULL);

  uint8_t *code;
  code = mmap((void*)CODE_BASE, MEMSPACE_SIZE, PROT_READ|PROT_WRITE,
              MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
  if (code == MAP_FAILED)
    return 1;

  printf("CODE: ");
  for (size_t i = 0; i < MEMSPACE_SIZE; i++)
    if (read(0, code + i, 1) != 1)
      return 1;

  vm_run(code);
  return 0;
}
