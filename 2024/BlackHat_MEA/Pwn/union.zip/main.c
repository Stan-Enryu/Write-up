#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TYPE_STRING  1
#define TYPE_INTEGER 2

typedef struct {
  union {
    char *string;
    long integer;
  } u;
  int type;
} storage;

storage data;

int menu() {
  int choice = 0;
  puts("1. New");
  puts("2. Edit");
  puts("3. Show");
  printf("> ");
  if (scanf("%d", &choice) != 1) exit(1);
  return choice;
}

int main(void) {
  long type;
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);

  while (1) {
    switch (menu()) {
    case 1:
      { /* New */
        printf("Type (1=String / 2=Integer): ");
        scanf("%ld", &type);
        data.type = type;
        if (data.type != TYPE_STRING && data.type != TYPE_INTEGER) {
          puts("[-] Invalid type");
          break;
        }
        printf("Data: ");
        if (type == TYPE_STRING) {
          scanf("%ms", &data.u.string);
        } else if (type == TYPE_INTEGER) {
          scanf("%ld", &data.u.integer);
        }
        break;
      }

    case 2:
      { /* Edit */
        printf("Data: ");
        if (data.type == TYPE_STRING) {
          scanf("%20s", data.u.string);
        } else if (data.type == TYPE_INTEGER) {
          scanf("%ld", &data.u.integer);
        } else {
          puts("<undefined>");
        }
        break;
      }

    case 3:
      { /* Show */
        if (data.type == TYPE_STRING) {
          printf("Data: %s\n", data.u.string);
        } else if (data.type == TYPE_INTEGER) {
          printf("Data: %ld\n", data.u.integer);
        } else {
          puts("<undefined>");
        }
        break;
      }

    default:
      puts("Bye!");
      return 0;
    }
  }
}
