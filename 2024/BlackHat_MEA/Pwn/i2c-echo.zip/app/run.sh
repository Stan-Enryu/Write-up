#!/bin/sh
./qemu-system-x86_64 \
    -L pc-bios \
    -cpu qemu64,+smap,+smep \
    -m 64M \
    -nographic \
    -kernel bzImage \
    -initrd rootfs.cpio \
    -append "console=ttyS0 loglevel=3 oops=panic panic=-1" \
    -no-reboot \
    -monitor /dev/null \
    -device i2c-echo,address=0x42 \
    -sandbox on
