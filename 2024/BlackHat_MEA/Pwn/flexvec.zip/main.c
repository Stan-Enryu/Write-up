#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  long *data;
  size_t size;
  size_t capacity;
} vector;

__attribute__((noreturn)) void oom() {
  puts("[-] Memory error");
  exit(1);
}

void _int_vector_resize(vector* vec, size_t size) {
  long *new;

  vec->capacity = size;
  if (!(new = (long*)malloc(vec->capacity * sizeof(long))))
    oom();

  memcpy(new, vec->data, vec->size * sizeof(long));
  free(vec->data);
  vec->data = new;
}

vector* vector_new(void) {
  vector *vec;

  if (!(vec = (vector*)malloc(sizeof(vector))))
    oom();

  vec->capacity = 4;
  vec->size = 0;
  if (!(vec->data = (long*)malloc(vec->capacity * sizeof(long))))
    oom();

  return vec;
}

void vector_push_back(vector* vec, long value) {
  if (vec->size == vec->capacity)
    _int_vector_resize(vec, vec->capacity * 2);

  vec->data[vec->size++] = value;
}

long vector_pop_back(vector *vec) {
  if (vec->size == 0) return 0;
  return vec->data[--vec->size];
}

void vector_shrink(vector *vec) {
  _int_vector_resize(vec, vec->size);
}

int main() {
  int choice;
  long value;
  vector *vec;

  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  setbuf(stderr, NULL);

  vec = vector_new();

  puts("1. push_back\n2. pop_back\n3. shrink");
  while (1) {
    printf("> ");
    if (scanf("%d%*c", &choice) != 1) break;

    switch (choice) {
      case 1:
        printf("value: ");
        if (scanf("%ld%*c", &value) != 1) break;
        vector_push_back(vec, value);
        break;

      case 2:
        printf("value: %ld\n", vector_pop_back(vec));
        break;

      case 3:
        vector_shrink(vec);
        break;

      default:
        return 0;
    }
  }

  return 1;
}
