#include <fcntl.h>
#include <linux/seccomp.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <unistd.h>

#define die(s) { write(2, s, strlen(s)); exit(1); }

static unsigned char filter[] = {
  32,0,0,0,4,0,0,0,21,0,0,8,62,0,0,192,32,0,0,0,0,0,0,0,53,0,6,0,0,0,0,
  64,21,0,6,0,2,0,0,0,21,0,5,0,1,1,0,0,21,0,4,0,0,0,0,0,21,0,3,0,1,0,0,0,
  21,0,2,0,60,0,0,0,21,0,1,0,231,0,0,0,6,0,0,0,1,0,5,0,6,0,0,0,0,0,255,127
};

static void install_seccomp() {
  struct prog {
    unsigned short len;
    unsigned char *filter;
  } rule = {
    .len = sizeof(filter) >> 3,
    .filter = filter
  };

  if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) < 0)
    die("prctl(PR_SET_NO_NEW_PRIVS)");

  if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &rule) < 0)
    die("prctl(PR_SET_SECCOMP)");
}

void print_file_content(const char *path, ssize_t size) {
  char *data;
  int fd;

  if (size < 0)
    die("Invalid size\n");

  data = (char*)alloca(size);

  if ((fd = open(path, O_RDONLY)) == -1)
    die("Cannot open file\n");

  for (ssize_t i = 0; i < size; i++)
    if (read(fd, data + i, 1) != 1)
      die("Truncated file\n");

  write(1, data, size);
  close(fd);
}

ssize_t read_line(char *buf, ssize_t size) {
  ssize_t i;
  for (i = 0; i < size; i++) {
    if (read(0, buf + i, 1) != 1) return -1;
    if (buf[i] == '\n') break;
  }
  buf[strcspn(buf, "\n")] = '\0';
  return i;
}

size_t read_int() {
  char buf[0x10] = { 0 };
  read_line(buf, sizeof(buf)-1);
  return atol(buf);
}

int main() {
  char path[PATH_MAX];
  ssize_t size;

  install_seccomp();

  while (1) {
    write(1, "File: ", 6);
    if (read_line(path, PATH_MAX-1) < 0) break;
    path[strcspn(path, "\n")] = '\0';

    write(1, "Size: ", 6);
    size = read_int();

    write(1, "Content:\n", 9);
    print_file_content(path, size);
    write(1, "\n", 1);
  }

  return 0;
}
